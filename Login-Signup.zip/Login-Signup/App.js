import React, { Component } from 'react';

import Routes from './src/components/Routes'

export default class App extends Component<{}>{
  render(){
    return(
      <Routes />
    );
  }
}