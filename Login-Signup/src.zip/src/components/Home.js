import React, {Component} from 'react';
import { Text} from 'react-native';
export default class Quiz extends Component {

    
  
    render() {
      return (
        <Text>This is Home Page</Text>
        
  
      );
    }
  }
  