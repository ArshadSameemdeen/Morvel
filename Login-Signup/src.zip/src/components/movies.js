import React, {Component} from 'react';
import { TouchableHighlight, Image, View,Text,ScrollView, StyleSheet, ImageBackground} from 'react-native';
import BackImage from '../assets/seats.jpg';
import { Actions } from 'react-native-router-flux';
import CheckBox from 'react-native-check-box';
export default class movies extends Component {

  constructor(props){
    super(props);
    this.state={
      isChecked1:false,
      isChecked2:false,
      isChecked3:false,
      isChecked4:false,
      isChecked5:false,
      isChecked6:false,
      isChecked7:false,
      isChecked8:false,
      isChecked9:false,
      isChecked10:false,
    }
  }

  Login(){
        Actions.Login();
    }
  
    render() {
      
      return (
        <ImageBackground source={BackImage} style={styles.BackImage}>
      
        <ScrollView  contentContainerStyle={styles.contentContainer}>
      
      
        <Text style={styles.heading}>SignUp Here</Text>
        <Text style={styles.heading1}>Step 3</Text>
        <Text style={styles.heading1}>Choose a movie you like</Text>

        <View style={styles.row}>
        
        <CheckBox
            style={{flex: 1, padding: 10}}
            onClick={()=>{
              this.setState({
                isChecked1:!this.state.isChecked1
              })
            }}
            isChecked={this.state.isChecked1}
            leftText={"CheckBox"}
        />
        <CheckBox
            style={{flex: 1, padding: 10}}
            onClick={()=>{
              this.setState({
                  isChecked2:!this.state.isChecked2
              })
            }}
            isChecked={this.state.isChecked2}
            leftText={"CheckBox"}
        />
        </View>

        <View style={styles.row}>
        <CheckBox
            style={{flex: 1, padding: 10}}
            onClick={()=>{
              this.setState({
                  isChecked3:!this.state.isChecked3
              })
            }}
            isChecked={this.state.isChecked3}
            leftText={"CheckBox"}
        />
        <CheckBox
            style={{flex: 1, padding: 10}}
            onClick={()=>{
              this.setState({
                  isChecked4:!this.state.isChecked4
              })
            }}
            isChecked={this.state.isChecked4}
            leftText={"CheckBox"}
        />
        </View>

        <View style={styles.row}>
        <CheckBox
            style={{flex: 1, padding: 10}}
            onClick={()=>{
              this.setState({
                  isChecked5:!this.state.isChecked5
              })
            }}
            isChecked={this.state.isChecked5}
            leftText={"CheckBox"}
        />
        <CheckBox
            style={{flex: 1, padding: 10}}
            onClick={()=>{
              this.setState({
                  isChecked6:!this.state.isChecked6
              })
            }}
            isChecked={this.state.isChecked6}
            leftText={"CheckBox"}
        />
        </View>

        <View style={styles.row}>
        <CheckBox
            style={{flex: 1, padding: 10}}
            onClick={()=>{
              this.setState({
                  isChecked7:!this.state.isChecked7
              })
            }}
            isChecked={this.state.isChecked7}
            leftText={"CheckBox"}
        />
        <CheckBox
            style={{flex: 1, padding: 10}}
            onClick={()=>{
              this.setState({
                  isChecked8:!this.state.isChecked8
              })
            }}
            isChecked={this.state.isChecked8}
            leftText={"CheckBox"}
        />
        </View>

        <View style={styles.row}>
        <CheckBox
            style={{flex: 1, padding: 10}}
            onClick={()=>{
              this.setState({
                  isChecked9:!this.state.isChecked9
              })
            }}
            isChecked={this.state.isChecked9}
            leftText={"CheckBox"}
        />
        <CheckBox
            style={{flex: 1, padding: 10}}
            onClick={()=>{
              this.setState({
                  isChecked10:!this.state.isChecked10
              })
            }}
            isChecked={this.state.isChecked10}
            leftText={"CheckBox"}
        />
        </View>
    
        
        
        {/* <View style={styles.row}>
        <View style={styles.inputContainer}>
        <TouchableHighlight onPress={this._onPressButton}>
      <Image
        style={styles.button}
        source={require('../assets/jaw.jpg')}
      />
    </TouchableHighlight>
    </View>

    <View style={styles.inputContainer}>
    <TouchableHighlight onPress={this._onPressButton}>
      <Image
        style={styles.button}
        source={require('../assets/jaw.jpg')}
      />
    </TouchableHighlight>
    </View>
    </View>

    <View style={styles.row}>
    <View style={styles.inputContainer}>
    <TouchableHighlight onPress={this._onPressButton}>
      <Image
        style={styles.button}
        source={require('../assets/jaw.jpg')}
      />
    </TouchableHighlight>
    </View>

    
      
    <TouchableHighlight onPress={this._onPressButton}>
    
      <Image
        style={styles.button}
        source={require('../assets/jaw.jpg')}
      />
      
    </TouchableHighlight>
    </View>
    
    <View style={styles.row}>
        <View style={styles.inputContainer}>
        <TouchableHighlight onPress={this._onPressButton}>
      <Image
        style={styles.button}
        source={require('../assets/jaw.jpg')}
      />
    </TouchableHighlight>
    </View>

    <View style={styles.inputContainer}>
    <TouchableHighlight onPress={this._onPressButton}>
      <Image
        style={styles.button}
        source={require('../assets/jaw.jpg')}
      />
    </TouchableHighlight>
    </View>
    </View>

    <View style={styles.row}>
        <View style={styles.inputContainer}>
        <TouchableHighlight onPress={this._onPressButton}>
      <Image
        style={styles.button}
        source={require('../assets/jaw.jpg')}
      />
    </TouchableHighlight>
    </View>

    <View style={styles.inputContainer}>
    <TouchableHighlight onPress={this._onPressButton}>
      <Image
        style={styles.button}
        source={require('../assets/jaw.jpg')}
      />
    </TouchableHighlight>
    </View>
    </View>

    <View style={styles.row}>
        <View style={styles.inputContainer}>
        <TouchableHighlight onPress={this._onPressButton}>
      <Image
        style={styles.button}
        source={require('../assets/jaw.jpg')}
      />
    </TouchableHighlight>
    </View>

    <View style={styles.inputContainer}>
    <TouchableHighlight onPress={this._onPressButton}>
      <Image
        style={styles.button}
        source={require('../assets/jaw.jpg')}
      />
    </TouchableHighlight>
    </View>
    </View> */}
 
         
    </ScrollView >
       </ImageBackground>
       
       
 
     );
   }
 }
 
 const styles = StyleSheet.create({
  contentContainer: {
    
     justifyContent: 'center',
     alignItems: 'center',
     
   },
   BackImage:{
     width: "100%",
     flex:1,
    
   },
   welcome: {
     fontSize: 20,
     textAlign: 'center',
     margin: 10,
   },
   instructions: {
     textAlign: 'center',
     color: '#333333',
     marginBottom: 5,
   },
   row:{
    flexDirection: 'row',
   },
   inputContainer:{
    
     margin: 20,
     marginBottom: 0,
     padding: 20,
     paddingBottom: 10,
     alignSelf: 'stretch',
     borderWidth: 1,
     borderColor: '#fff',
     backgroundColor: 'rgba(255,255,255,0.2)'
 },
 heading:{
   color: "white",
   fontSize: 40,
   fontWeight: "bold",
   fontStyle: "italic",
   textShadowColor: '#252525',
   textShadowOffset: {width: 2, height: 2},
   textShadowRadius: 25,
   marginBottom: 20
 },
 heading1:{
  color: "white",
  fontSize: 20,
  fontWeight: "bold",
  fontStyle: "italic",
  textShadowColor: '#252525',
  textShadowOffset: {width: 2, height: 2},
  textShadowRadius: 25,
  marginBottom: 20
},

 
 
   input:{
     fontSize:16,
     height: 40,
     padding:10,
     marginBottom: 10,
     backgroundColor: 'rgba(255,255,255,1)'
 },
 button: {
  flexDirection: 'row',
  justifyContent: 'center',
     alignItems: 'center',
   flex:1,
   width: 120,
   height: 200,
   color: 'blue',
   alignSelf: 'stretch',
   margin: 1,
   padding: 1,
   backgroundColor: 'blue',
   borderWidth: 1,
   borderColor: '#fff',
   backgroundColor: 'rgba(255,255,255,0.6)'
 },
  buttonText: {
     textAlign: 'center',
     fontWeight: 'bold',
     fontSize: 16,
   }
 });
        
  
